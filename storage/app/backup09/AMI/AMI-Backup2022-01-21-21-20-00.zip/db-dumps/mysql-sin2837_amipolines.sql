
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `bahan_rapattm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bahan_rapattm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tm_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bahan_rapattm_tm_id_foreign` (`tm_id`),
  CONSTRAINT `bahan_rapattm_tm_id_foreign` FOREIGN KEY (`tm_id`) REFERENCES `tinjauan_manajemen` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bahan_rapattm` WRITE;
/*!40000 ALTER TABLE `bahan_rapattm` DISABLE KEYS */;
INSERT INTO `bahan_rapattm` VALUES (2,'masalah yang belum teratasi','aktif',3,'2022-01-16 11:45:00','2022-01-16 20:08:55'),(3,'koneksi','aktif',4,'2022-01-16 13:01:58','2022-01-16 20:01:58');
/*!40000 ALTER TABLE `bahan_rapattm` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bukti_kinerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bukti_kinerja` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `namaBukti` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokDokBukti` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun` year(4) NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('terbaik','normal','terburuk') COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitkerja_id` int(10) unsigned NOT NULL,
  `renop_id` int(10) unsigned NOT NULL,
  `kinerjaUnit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bukti_kinerja_kinerjaunit_id_foreign` (`kinerjaUnit_id`),
  CONSTRAINT `bukti_kinerja_kinerjaunit_id_foreign` FOREIGN KEY (`kinerjaUnit_id`) REFERENCES `kinerja_unit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bukti_kinerja` WRITE;
/*!40000 ALTER TABLE `bukti_kinerja` DISABLE KEYS */;
INSERT INTO `bukti_kinerja` VALUES (1,'Pelatihan','storage/files/Pusat/Unit Kerja/Pusat Penjaminan Mutu Pendidikan (PPMP)/BuktiKinerja/2022/bukti_kinerja.PNG',2021,'Pelatihan dari Kemenristekdikti','terbaik',4,1,1,'2022-01-09 00:43:07','2022-01-09 10:16:46');
/*!40000 ALTER TABLE `bukti_kinerja` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `car` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `analisiPenyebabMasalah` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tindakanPenyelesaian` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tindakanPencegahan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasilPemeriksaan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rekomendasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('open','process','closed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `laporanaudit_id` int(10) unsigned NOT NULL,
  `acc` int(20) DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `car_laporanaudit_id_foreign` (`laporanaudit_id`),
  CONSTRAINT `car_laporanaudit_id_foreign` FOREIGN KEY (`laporanaudit_id`) REFERENCES `laporan_audit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `car` WRITE;
/*!40000 ALTER TABLE `car` DISABLE KEYS */;
INSERT INTO `car` VALUES (2,'pembelajaran kurang aktif','media online','tidak terlalu lama memakai daring',NULL,NULL,'process',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Akademik, Kemahasiswaan, Perencanaan dan Kerjasama (BAKPK)/CAR/2022/CARBAKPK.pdf','2022-01-15 15:52:26','2022-01-16 15:46:29'),(3,'pembelajaran monoton','e learning','tidak terlalu lama memakai daring',NULL,NULL,'open',3,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/CARBUK.pdf','2022-01-15 15:52:26','2022-01-15 22:52:26'),(4,'tes123','tes321','testing',NULL,NULL,'open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/CARBAKPK.pdf','2022-01-16 04:43:18','2022-01-16 11:43:18'),(5,'perbaikan 123',NULL,NULL,NULL,NULL,'open',1,NULL,NULL,'2022-01-16 04:45:13','2022-01-16 11:45:13'),(6,'perbaikan321','cek321','cegah321',NULL,NULL,'open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/CARBAKPK.pdf','2022-01-16 04:45:13','2022-01-16 11:58:02'),(7,'coba cek123','woke123','tes90898','diakui','rekomen','open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/WhatsApp Image 2019-05-28 at 14.21.48.jpeg','2022-01-16 05:15:48','2022-01-16 12:15:48'),(8,'tes098','yoa123','dfg34455','diacc','rekomendasi','open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/Sertifikat.pdf','2022-01-16 05:15:48','2022-01-16 12:15:48'),(9,'tes auditor1','dengan melakukan analisa','metodologi',NULL,NULL,'open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/CARBAKPK.pdf','2022-01-16 05:16:41','2022-01-16 12:17:49'),(10,'tes auditor2',NULL,NULL,NULL,NULL,'open',1,NULL,NULL,'2022-01-16 05:16:41','2022-01-16 12:16:41'),(11,'analisa 123','penyelesai 1234','cegah 1234','testing','testonggo','process',1,2,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/NOC Supervisor - Mohammad Susilo.pdf','2022-01-16 05:20:15','2022-01-16 13:33:56'),(12,'analisa456',NULL,NULL,NULL,NULL,'open',1,NULL,NULL,'2022-01-16 05:20:15','2022-01-16 12:20:15'),(13,'analisa 098',NULL,NULL,'hasil 098','rekomen 098','open',1,NULL,NULL,'2022-01-16 05:22:25','2022-01-16 12:22:25'),(14,'analisa 765',NULL,NULL,'hasil 765','rekomen 765','open',1,NULL,NULL,'2022-01-16 05:22:25','2022-01-16 12:22:25'),(15,'analisa 5758',NULL,NULL,'hasil 5758','rekomen5758','open',1,NULL,NULL,'2022-01-16 05:35:38','2022-01-16 12:35:38'),(16,'analisa 4060','tindak 4060','cegah 4060','hasil 4060','rekomen 4060','open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/CARBUK.pdf','2022-01-16 05:36:55','2022-01-16 12:36:55'),(17,'Pembelajaran daring yang terkendala koneksi','mengganti ISP','Memiliki server backup koneksi sendiri',NULL,NULL,'open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/6.PNG','2022-01-16 08:44:13','2022-01-16 15:44:13'),(18,'Pembelajaran daring yang terkendala koneksi','mengganti ISP','Memiliki server backup koneksi sendiri',NULL,NULL,'open',1,NULL,'storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)/CAR/2022/7.PNG','2022-01-16 08:44:13','2022-01-16 15:44:13');
/*!40000 ALTER TABLE `car` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dokumencheklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dokumencheklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun` year(4) NOT NULL,
  `lokasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitkerja_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dokumencheklist_unitkerja_id_foreign` (`unitkerja_id`),
  CONSTRAINT `dokumencheklist_unitkerja_id_foreign` FOREIGN KEY (`unitkerja_id`) REFERENCES `unitkerja` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dokumencheklist` WRITE;
/*!40000 ALTER TABLE `dokumencheklist` DISABLE KEYS */;
INSERT INTO `dokumencheklist` VALUES (2,'Checklist Area Akuntansi',2022,'storage/files/Pusat/PPMP/Dokumen Checklist/2022/Area AMI Tahun 2021 (1)-dikonversi.pdf','aktif',17,'2022-01-03 08:11:52','2022-01-03 08:11:52');
/*!40000 ALTER TABLE `dokumencheklist` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dokumeninduk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dokumeninduk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun_aktif` year(4) NOT NULL,
  `tahun_selesai` year(4) NOT NULL,
  `nomor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dokumeninduk` WRITE;
/*!40000 ALTER TABLE `dokumeninduk` DISABLE KEYS */;
INSERT INTO `dokumeninduk` VALUES (2,'SPMI',2021,2024,'SPMI/01','4','aktif','storage/files/Pusat/PPMP/Dokumen Induk/2022/Area AMI Tahun 2021-2024.pdf','2021-12-27 04:40:28','2022-01-03 13:48:35'),(6,'Perjanjian Kinerja',2021,2024,'0531/PL4.6.2/PK/2021','1','aktif','storage/files/Pusat/PPMP/Dokumen Induk/2022/PK_2021.pdf','2022-01-07 07:09:41','2022-01-07 07:09:41');
/*!40000 ALTER TABLE `dokumeninduk` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subjek` varchar(255) NOT NULL,
  `uraian` varchar(255) NOT NULL,
  `urutan` int(10) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,'Cara Pengunnaan Audit Mutu Internal?','deskripsiAudit Mutu',1,'aktif','2021-12-24 04:43:13','2021-12-24 05:42:19'),(2,'TES2','DESC2',2,'nonaktif','2021-12-24 08:08:10','2021-12-24 08:28:39');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `frontEnd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frontEnd` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tittle` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL,
  `welcome` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `frontEnd` WRITE;
/*!40000 ALTER TABLE `frontEnd` DISABLE KEYS */;
INSERT INTO `frontEnd` VALUES (1,'Audit Mutu Internal','storage/files/Pusat/Setting/nav2.png','storage/files/Pusat/Setting/apple-icon-152x152.png','Selamat Datang Di Audit Mutu Internal Politeknik Negeri Semarang','2021-12-24 14:34:20','2021-12-24 21:34:20');
/*!40000 ALTER TABLE `frontEnd` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `frontEnd_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frontEnd_banner` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL,
  `frontend_id` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `frontend_id` (`frontend_id`),
  CONSTRAINT `frontEnd_banner_ibfk_1` FOREIGN KEY (`frontend_id`) REFERENCES `frontEnd` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `frontEnd_banner` WRITE;
/*!40000 ALTER TABLE `frontEnd_banner` DISABLE KEYS */;
INSERT INTO `frontEnd_banner` VALUES (1,'Langkah-Langkah Penggunaan AMI','Langkah-Langkah Penggunaan AMI','storage/files/Pusat/Setting/Banner/1.jpg','aktif',1,'2021-12-24 14:29:56','2021-12-24 21:29:56'),(2,'Jadwal AMI 2022','Jadwal AMI 2022','storage/files/Pusat/Setting/Banner/2.jpg','aktif',1,'2021-12-24 14:30:35','2021-12-24 21:30:35'),(3,'contoh 1','des1','Setting/Banner/images.jpg','aktif',1,'2021-12-24 11:07:55','2021-12-24 18:07:55'),(4,'contoh 2','des2','Setting/Banner/2c93a894-f06d-4b82-b3c7-f1ebc05aa8cc.png','aktif',1,'2021-12-24 11:07:55','2021-12-24 18:07:55');
/*!40000 ALTER TABLE `frontEnd_banner` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `hasil_rapattm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hasil_rapattm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subjek` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uraian` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hasilPembahasan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hadir` int(255) NOT NULL,
  `tidakHadir` int(255) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tm_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hasil_rapattm_tm_id_foreign` (`tm_id`),
  CONSTRAINT `hasil_rapattm_tm_id_foreign` FOREIGN KEY (`tm_id`) REFERENCES `tinjauan_manajemen` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `hasil_rapattm` WRITE;
/*!40000 ALTER TABLE `hasil_rapattm` DISABLE KEYS */;
INSERT INTO `hasil_rapattm` VALUES (1,'hasil TM1','desk 1','hasil 1',5,3,'aktif',3,'2022-01-16 11:45:41','2022-01-16 18:45:41'),(2,'Hasil TM','Temuan masalah','solusi masalah',5,0,'aktif',4,'2022-01-17 06:50:02','2022-01-17 13:50:02'),(3,'Hasil TM 2','memecahkan masalah','mendapatkan solusi terbaik',4,0,'aktif',3,'2022-01-17 07:14:05','2022-01-17 14:23:21');
/*!40000 ALTER TABLE `hasil_rapattm` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jadwal_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jadwal_audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tahun` year(4) NOT NULL,
  `periode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tglAudit` date NOT NULL,
  `waktu` time NOT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitkerja_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jadwal_audit` WRITE;
/*!40000 ALTER TABLE `jadwal_audit` DISABLE KEYS */;
INSERT INTO `jadwal_audit` VALUES (1,2021,'1','2021-12-06','09:00:00','aktif',2,'2021-12-27 05:37:30','2022-01-15 22:03:44'),(3,2022,'1','2022-01-15','09:00:00','aktif',35,'2022-01-15 06:42:43','2022-01-15 13:42:43'),(4,2023,'1','2022-01-15','09:00:00','aktif',38,'2022-01-15 06:42:43','2022-01-15 13:42:43'),(5,2022,'1','2022-01-16','09:00:00','aktif',28,'2022-01-15 13:39:52','2022-01-15 20:39:52');
/*!40000 ALTER TABLE `jadwal_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `kinerja_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kinerja_unit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nilaiCapaian` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun` year(4) NOT NULL,
  `unitCapaian` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('terbaik','normal','terjelek') COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitkerja_id` int(10) unsigned NOT NULL,
  `renop_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kinerja_unit_renop_id_foreign` (`renop_id`),
  CONSTRAINT `kinerja_unit_renop_id_foreign` FOREIGN KEY (`renop_id`) REFERENCES `renop` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `kinerja_unit` WRITE;
/*!40000 ALTER TABLE `kinerja_unit` DISABLE KEYS */;
INSERT INTO `kinerja_unit` VALUES (1,'90',2021,'90','Kinerja Unit','terbaik',4,1,'2022-01-08 05:14:25','2022-01-08 12:14:25'),(3,'10',2022,'9','Kinerja Unit 2','terbaik',1,2,'2022-01-08 06:34:03','2022-01-08 13:34:03');
/*!40000 ALTER TABLE `kinerja_unit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laporan_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laporan_audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `standar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategoriTemuan` enum('OFI','AOC','NC') COLLATE utf8mb4_unicode_ci NOT NULL,
  `uraianTemuan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `saranPerbaikan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('selesai','nonselesai') COLLATE utf8mb4_unicode_ci NOT NULL,
  `audit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `laporan_audit_audit_id_foreign` (`audit_id`),
  CONSTRAINT `laporan_audit_audit_id_foreign` FOREIGN KEY (`audit_id`) REFERENCES `jadwal_audit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laporan_audit` WRITE;
/*!40000 ALTER TABLE `laporan_audit` DISABLE KEYS */;
INSERT INTO `laporan_audit` VALUES (1,'SPd.1.02 Standar Isi Pembelajaran','AOC','Pembelajaran daring yang terkendala koneksi','Memperbaiki koneksi sebelum daring','nonselesai',1,'2022-01-15 07:57:07','2022-01-15 22:07:24'),(3,'SPd.1.02 Standar Isi Pembelajaran','NC','koneksi yang buruk','Memperbaiki koneksi sebelum daring','selesai',4,'2022-01-15 13:42:58','2022-01-15 20:42:58'),(4,'SPd.1.02 Standar Isi Pembelajaran 2022','OFI','koneksi yang buruk','Memperbaiki koneksi sebelum daring','selesai',1,'2022-01-15 13:42:58','2022-01-16 10:30:21');
/*!40000 ALTER TABLE `laporan_audit` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `master` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sorting` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Home','main_menu_0',0,'/','fas fa-home','1,2,3,4','1','aktif','2021-06-29 07:02:08','2021-06-29 07:02:08'),(2,'Dashboard','main_menu_1',0,'dashboard','fas fa-tachometer-alt','1,2,3,4','2','aktif','2021-06-29 07:02:08','2021-06-29 07:02:08'),(3,'Master Data','main_menu_2',0,'','fa fa-database','1,2,3','3','aktif','2021-06-29 07:02:08','2021-06-29 07:02:08'),(4,'Dokumen Acuan, Renop, & Dokumen','sub_menu_2',1,'renstraRenop.index','far fa-circle','1,2,3','4','aktif','2021-06-29 07:02:08','2021-06-29 07:02:08'),(5,'Pimpinan, Pengelola, &  Unit Kerja','sub_menu_2',1,'pimpinanUK.index','far fa-circle','1','5','aktif',NULL,NULL),(11,'AMI','main_menu_3',0,'ami.index','fas fa-newspaper','1,2,3','11','aktif',NULL,NULL),(12,'Tinjauan Manajemen','main_menu_4',0,'tinjauanManajemen.index','fas fa-newspaper','1,2,3','12','aktif',NULL,NULL),(16,'Reports','main_menu_5',0,'','fas fa-copy','1,4','16','aktif',NULL,NULL),(17,'Chart','sub_menu_5',1,'chart.index','far fa-circle','1,4','17','aktif',NULL,NULL),(18,'Periode','sub_menu_5',1,'chart.create','far fa-circle','1,4','18','aktif',NULL,NULL),(25,'Master Pengguna','main_menu_6',0,'','fas fa-users','1','25','aktif',NULL,NULL),(26,'Pengguna','sub_menu_6',1,'users.index','far fa-circle','1','26','aktif',NULL,NULL),(27,'Rule','sub_menu_6',1,'roles.index','far fa-circle','1','27','aktif',NULL,NULL),(28,'Apps','main_menu_7',0,'','fab fa-app-store','1','28','aktif',NULL,NULL),(29,'Setting Apps','sub_menu_7',1,'setting','far fa-circle','1','29','aktif',NULL,NULL),(30,'File Manager','sub_menu_7',1,'filemanager','far fa-circle','1','30','aktif',NULL,NULL),(31,'Menu','sub_menu_7',1,'menu','far fa-circle','1','31','aktif',NULL,NULL),(32,'Backup','sub_menu_7',1,'backup','far fa-circle','1','32','aktif',NULL,NULL),(33,'Documentation','main_menu_8',0,'','fa fa-book','1,2,3','33','aktif',NULL,NULL),(34,'Logout','main_menu_9',0,'','fas fa-sign-out-alt','1,2,3','34','aktif',NULL,NULL),(44,'Scheduling','sub_menu_3',1,'auditor/scheduling','far fa-circle','','','aktif',NULL,NULL),(45,'Scheduling','sub_menu_3',1,'auditee/scheduling','far fa-circle','','','aktif',NULL,NULL),(46,'CAR Reports','sub_menu_3',1,'auditor/CarReports','far fa-circle','','','aktif',NULL,NULL),(47,'CAR Reports','sub_menu_3',1,'auditee/CarReports','far fa-circle','','','aktif',NULL,NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(6,'2021_08_19_120947_create_jadwal_audits_table',2),(7,'2021_08_19_123851_create_kinerja_units_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pengelola_pimpinan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pengelola_pimpinan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pimpinan_id` int(10) unsigned NOT NULL,
  `pengelola_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pengelola_pimpinan_pimpinan_id_foreign` (`pimpinan_id`),
  KEY `pengelola_pimpinan_pengelola_id_foreign` (`pengelola_id`),
  CONSTRAINT `pengelola_pimpinan_pengelola_id_foreign` FOREIGN KEY (`pengelola_id`) REFERENCES `pengelolaunitkerja` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pengelola_pimpinan_pimpinan_id_foreign` FOREIGN KEY (`pimpinan_id`) REFERENCES `pimpinan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pengelola_pimpinan` WRITE;
/*!40000 ALTER TABLE `pengelola_pimpinan` DISABLE KEYS */;
INSERT INTO `pengelola_pimpinan` VALUES (22,12,1,'2021-07-18 21:01:59','2021-07-19 04:01:59'),(23,15,1,'2021-07-18 21:01:59','2021-07-19 04:01:59'),(24,12,2,'2021-07-18 21:02:37','2021-07-19 04:02:37'),(26,12,3,'2021-07-18 21:03:07','2021-07-19 04:03:07'),(27,13,3,'2021-07-18 21:03:07','2021-07-19 04:03:07'),(28,12,4,'2021-07-18 21:03:56','2021-07-19 04:03:56'),(29,13,4,'2021-07-18 21:03:56','2021-07-19 04:03:56'),(30,15,5,'2021-07-18 21:04:20','2021-07-19 04:04:20'),(41,13,2,'2021-08-11 10:42:11','2021-08-11 17:42:11'),(42,14,2,'2021-08-11 10:44:40','2021-08-11 17:44:40'),(43,12,5,'2021-08-11 11:05:25','2021-08-11 18:05:25'),(44,12,6,'2021-08-11 11:05:25','2021-08-11 18:05:25');
/*!40000 ALTER TABLE `pengelola_pimpinan` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pengelolaunitkerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pengelolaunitkerja` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pengelolaunitkerja` WRITE;
/*!40000 ALTER TABLE `pengelolaunitkerja` DISABLE KEYS */;
INSERT INTO `pengelolaunitkerja` VALUES (1,'Jurusan Elektro','aktif','2021-07-18 21:01:59','2021-07-18 21:01:59'),(2,'Jurusan Mesin','aktif','2021-07-18 21:02:37','2021-07-18 21:02:37'),(3,'Jurusan Sipil','aktif','2021-07-18 21:03:07','2021-07-18 21:03:07'),(4,'Jurusan Administrasi Bisnis','aktif','2021-07-18 21:03:56','2021-07-18 21:03:56'),(5,'Jurusan Akuntansi','aktif','2021-07-18 21:04:19','2021-07-18 21:04:19'),(6,'Pusat','aktif','2021-07-18 21:04:38','2021-07-18 21:04:38');
/*!40000 ALTER TABLE `pengelolaunitkerja` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pimpinan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pimpinan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pimpinan` WRITE;
/*!40000 ALTER TABLE `pimpinan` DISABLE KEYS */;
INSERT INTO `pimpinan` VALUES (12,'Prof. Dr. Totok Prasetyo, B.Eng (Hons), M.T., IPU, ACPE','D0','2021-07-18 09:08:40','2021-12-15 10:25:15'),(13,'Ir. Endro Wasito, M.Kom.','WD1','2021-07-18 09:09:07','2021-07-18 09:09:07'),(14,'Saniman Widodo, S.E., M.M.','WD2','2021-07-18 09:09:22','2021-07-18 09:09:22'),(15,'Adhy Purnomo, S.T., M.T.','WD3','2021-07-18 09:09:30','2021-07-18 09:09:30'),(16,'Drs. Budi Prasetya, M.Si.','WD4','2021-07-18 09:10:09','2021-07-18 09:10:09');
/*!40000 ALTER TABLE `pimpinan` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jabatan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_user_id_foreign` (`user_id`),
  CONSTRAINT `profile_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'Admin PPMP','storage/files/Pusat/Profile/2021/avatar4.png','storage/files/Pusat/Profile/2021/61c7fdcf19587.png',1,'2021-09-03 17:31:08','2021-12-26 05:29:51'),(2,NULL,NULL,NULL,2,'2021-12-27 05:07:12','2021-12-27 05:07:12'),(3,NULL,NULL,NULL,3,'2021-12-27 05:07:12','2021-12-27 05:07:12'),(4,NULL,NULL,NULL,5,'2021-12-27 05:21:58','2021-12-27 05:21:58'),(5,NULL,NULL,NULL,6,'2021-12-27 05:27:26','2021-12-27 05:27:26'),(6,NULL,NULL,NULL,7,'2022-01-19 06:49:35','2022-01-19 06:49:35'),(7,NULL,NULL,NULL,8,'2022-01-19 11:14:02','2022-01-19 11:14:02');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `renop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `renop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` int(11) NOT NULL,
  `unit_target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun` year(4) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitkerja_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `renop_unitkerja_id_foreign` (`unitkerja_id`),
  CONSTRAINT `renop_unitkerja_id_foreign` FOREIGN KEY (`unitkerja_id`) REFERENCES `unitkerja` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `renop` WRITE;
/*!40000 ALTER TABLE `renop` DISABLE KEYS */;
INSERT INTO `renop` VALUES (1,'RP001','Komitmen mutu',80,'100',2022,'aktif',4,'2022-01-08 01:39:57','2022-01-08 01:39:57'),(2,'RP002','Rencana Operasional 2021',90,'100',2021,'aktif',1,'2022-01-08 03:37:02','2022-01-08 03:50:54');
/*!40000 ALTER TABLE `renop` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `renop_renstra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `renop_renstra` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `renop_id` int(10) unsigned NOT NULL,
  `renstra_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `renop_renstra_renop_id_foreign` (`renop_id`),
  KEY `renop_renstra_renstra_id_foreign` (`renstra_id`),
  CONSTRAINT `renop_renstra_renop_id_foreign` FOREIGN KEY (`renop_id`) REFERENCES `renop` (`id`) ON DELETE CASCADE,
  CONSTRAINT `renop_renstra_renstra_id_foreign` FOREIGN KEY (`renstra_id`) REFERENCES `renstra` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `renop_renstra` WRITE;
/*!40000 ALTER TABLE `renop_renstra` DISABLE KEYS */;
INSERT INTO `renop_renstra` VALUES (1,1,3,'2022-01-08 01:39:57','2022-01-08 08:39:57'),(2,2,1,'2022-01-08 03:37:02','2022-01-08 10:37:02');
/*!40000 ALTER TABLE `renop_renstra` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `renstra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `renstra` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` int(11) NOT NULL,
  `unit_target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe_indikator` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun` year(4) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referensi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` enum('renstra','PK') COLLATE utf8mb4_unicode_ci NOT NULL,
  `dokumen_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `renstra_dokumen_id_foreign` (`dokumen_id`),
  CONSTRAINT `renstra_dokumen_id_foreign` FOREIGN KEY (`dokumen_id`) REFERENCES `dokumeninduk` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `renstra` WRITE;
/*!40000 ALTER TABLE `renstra` DISABLE KEYS */;
INSERT INTO `renstra` VALUES (1,'PK2021','Perjanjian Kinerja Tahun 2021 Direktur Politeknik Negeri Semarang Dengan Direktur Jenderal Pendidikan Vokasi',55,'100','angka',2021,'aktif','PK1','PK',6,'2022-01-07 14:31:58','2022-01-11 07:30:52'),(3,'RS2020','Renstra 2020-2024',96,'100','%',2020,'aktif','rs20','renstra',2,'2022-01-07 15:08:31','2022-01-07 15:08:31');
/*!40000 ALTER TABLE `renstra` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin','Super Admin AMI','aktif','2021-07-08 08:00:29','2021-08-05 17:41:03'),(2,'Auditor','Auditor AMI','aktif','2021-07-08 08:00:29','2021-12-23 12:26:22'),(3,'Auditee','Auditee AMI','aktif','2021-07-08 08:00:29','2021-07-08 08:00:29'),(4,'Pimpinan','Pimpinan AMI','aktif','2021-08-03 06:51:34','2021-08-03 06:51:34');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tindak_lanjuttm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tindak_lanjuttm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tindakLanjut` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `realisasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PIC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('selesai','nonselesai') COLLATE utf8mb4_unicode_ci NOT NULL,
  `hslrpt_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tindak_lanjuttm_hslrpt_id_foreign` (`hslrpt_id`),
  CONSTRAINT `tindak_lanjuttm_hslrpt_id_foreign` FOREIGN KEY (`hslrpt_id`) REFERENCES `hasil_rapattm` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tindak_lanjuttm` WRITE;
/*!40000 ALTER TABLE `tindak_lanjuttm` DISABLE KEYS */;
INSERT INTO `tindak_lanjuttm` VALUES (1,'Dikenali dengan user',NULL,'3','selesai',1,'2022-01-16 11:50:09','2022-01-16 18:50:09'),(3,'Mengganti ISP dan Perangkat',NULL,'3','selesai',2,'2022-01-19 04:16:43','2022-01-19 11:47:03'),(4,'tindak lanjut tm1',NULL,'3','selesai',1,'2022-01-19 04:42:23','2022-01-19 11:42:23'),(5,'tindak lanjut tm2',NULL,'3','selesai',3,'2022-01-19 04:42:23','2022-01-19 11:42:23');
/*!40000 ALTER TABLE `tindak_lanjuttm` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tinjauan_manajemen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tinjauan_manajemen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tahun` year(4) NOT NULL,
  `tglTM` date NOT NULL,
  `waktuTM` time NOT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `audit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tinjauan_manajemen_audit_id_foreign` (`audit_id`),
  CONSTRAINT `tinjauan_manajemen_audit_id_foreign` FOREIGN KEY (`audit_id`) REFERENCES `jadwal_audit` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tinjauan_manajemen` WRITE;
/*!40000 ALTER TABLE `tinjauan_manajemen` DISABLE KEYS */;
INSERT INTO `tinjauan_manajemen` VALUES (3,2022,'2022-06-10','11:00:00','aktif',3,'2022-01-16 10:40:23','2022-01-16 17:40:23'),(4,2022,'2022-08-16','12:00:00','aktif',4,'2022-01-16 12:05:03','2022-01-16 19:05:03');
/*!40000 ALTER TABLE `tinjauan_manajemen` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unitkerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unitkerja` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `namaRepo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pengelola_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unitkerja_pengelola_id_foreign` (`pengelola_id`),
  CONSTRAINT `unitkerja_pengelola_id_foreign` FOREIGN KEY (`pengelola_id`) REFERENCES `pengelolaunitkerja` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `unitkerja` WRITE;
/*!40000 ALTER TABLE `unitkerja` DISABLE KEYS */;
INSERT INTO `unitkerja` VALUES (1,'Bagian Akademik, Kemahasiswaan, Perencanaan dan Kerjasama (BAKPK)','storage/files/Pusat/Unit Kerja/Bagian Akademik, Kemahasiswaan, Perencanaan dan Kerjasama (BAKPK)','aktif',6,'2021-07-28 22:37:42','2021-07-28 22:37:42'),(2,'Bagian Umum dan Keuangan (BUK)','storage/files/Pusat/Unit Kerja/Bagian Umum dan Keuangan (BUK)','aktif',6,'2021-08-02 06:08:02','2021-08-02 06:08:02'),(3,'Pusat Pengembangan Pembelajaran (PPP)','storage/files/Pusat/Unit Kerja/Pusat Pengembangan Pembelajaran (PPP)','aktif',6,'2021-08-02 06:08:59','2021-08-02 06:08:59'),(4,'Pusat Penjaminan Mutu Pendidikan (PPMP)','storage/files/Pusat/Unit Kerja/Pusat Penjaminan Mutu Pendidikan (PPMP)','aktif',6,'2021-08-02 06:15:11','2021-08-02 06:15:11'),(5,'Pusat Penelitian dan Pengabdian kepada Masyarakat (P3M)','storage/files/Pusat/Unit Kerja/Pusat Penelitian dan Pengabdian kepada Masyarakat (P3M)','aktif',6,'2021-08-02 06:17:07','2021-12-21 16:44:43'),(6,'UPT Perpustakaan','storage/files/Pusat/Unit Kerja/UPT Perpustakaan','aktif',6,'2021-08-02 06:18:58','2021-08-02 06:18:58'),(7,'UPT Bahasa','storage/files/Pusat/Unit Kerja/UPT Bahasa','aktif',6,'2021-08-02 06:20:34','2021-08-02 06:20:34'),(8,'UPT Teknologi Informasi dan Komunikasi (UPT TIK)','storage/files/Pusat/Unit Kerja/UPT Teknologi Informasi dan Komunikasi (UPT TIK)','aktif',6,'2021-08-02 06:23:12','2021-08-02 06:23:12'),(9,'UPT Pemeliharaan dan Perbaikan Sarana Pendidikan (UPT PPSP)','storage/files/Pusat/Unit Kerja/UPT Pemeliharaan dan Perbaikan Sarana Pendidikan (UPT PPSP)','aktif',6,'2021-08-02 06:32:39','2021-08-02 06:32:39'),(10,'Unit Hubungan Industri','storage/files/Pusat/Unit Kerja/Unit Hubungan Industri','aktif',6,'2021-08-02 06:33:10','2021-08-02 06:33:10'),(11,'Unit Urusan Internasional','storage/files/Pusat/Unit Kerja/Unit Urusan Internasional','aktif',6,'2021-08-02 06:35:27','2021-08-02 06:35:27'),(12,'Unit Layanan Pengadaan','storage/files/Pusat/Unit Kerja/Unit Layanan Pengadaan','aktif',6,'2021-08-02 06:35:37','2021-08-02 06:35:37'),(13,'Komputerisasi Akuntansi','storage/files/Pusat/Unit Kerja/Komputerisasi Akuntansi','aktif',5,'2021-12-23 08:56:02','2021-12-23 08:56:02'),(14,'Akuntansi Manajerial','storage/files/Pusat/Unit Kerja/Akuntansi Manajerial','aktif',5,'2021-12-23 08:56:13','2021-12-23 08:56:13'),(15,'Perbankan Syariah','storage/files/Pusat/Unit Kerja/Perbankan Syariah','aktif',5,'2021-12-23 08:56:21','2021-12-23 08:56:21'),(16,'Analis Keuangan','storage/files/Pusat/Unit Kerja/Analis Keuangan','aktif',5,'2021-12-23 08:56:28','2021-12-23 08:56:28'),(17,'Akuntansi','storage/files/Pusat/Unit Kerja/Akuntansi','aktif',5,'2021-12-23 08:56:38','2021-12-23 08:56:38'),(18,'Keuangan dan Perbankan','storage/files/Pusat/Unit Kerja/Keuangan dan Perbankan','aktif',5,'2021-12-23 08:56:48','2021-12-23 08:56:48'),(19,'Manajemen Bisnis Internasional','storage/files/Pusat/Unit Kerja/Manajemen Bisnis Internasional','aktif',4,'2021-12-23 08:56:58','2021-12-23 08:56:58'),(20,'Administrasi Bisnis Terapan','storage/files/Pusat/Unit Kerja/Administrasi Bisnis Terapan','aktif',4,'2021-12-23 08:57:04','2021-12-23 08:57:04'),(21,'Administrasi Bisnis','storage/files/Pusat/Unit Kerja/Administrasi Bisnis','aktif',4,'2021-12-23 08:57:11','2021-12-23 08:57:11'),(22,'Manajemen Pemasaran','storage/files/Pusat/Unit Kerja/Manajemen Pemasaran','aktif',4,'2021-12-23 08:57:17','2021-12-23 08:57:17'),(23,'Teknik Perawatan dan Perbaikan Gedung','storage/files/Pusat/Unit Kerja/Teknik Perawatan dan Perbaikan Gedung','aktif',3,'2021-12-23 08:57:33','2021-12-23 08:57:33'),(24,'Perancangan Jalan dan Jembatan','storage/files/Pusat/Unit Kerja/Perancangan Jalan dan Jembatan','aktif',3,'2021-12-23 08:57:40','2021-12-23 08:57:40'),(25,'Konstruksi Gedung','storage/files/Pusat/Unit Kerja/Konstruksi Gedung','aktif',3,'2021-12-23 08:57:48','2021-12-23 08:57:48'),(26,'Konstruksi Sipil','storage/files/Pusat/Unit Kerja/Konstruksi Sipil','aktif',3,'2021-12-23 08:57:57','2021-12-23 08:57:57'),(27,'Teknik Mesin Produksi dan Perawatan','storage/files/Pusat/Unit Kerja/Teknik Mesin Produksi dan Perawatan','aktif',2,'2021-12-23 08:58:09','2021-12-23 08:58:09'),(28,'Teknologi Rekayasa Pembangkit Energi','storage/files/Pusat/Unit Kerja/Teknologi Rekayasa Pembangkit Energi','aktif',2,'2021-12-23 08:58:16','2021-12-23 08:58:16'),(29,'Teknik Mesin','storage/files/Pusat/Unit Kerja/Teknik Mesin','aktif',2,'2021-12-23 08:58:23','2021-12-23 08:58:23'),(30,'Teknik Konversi Energi','storage/files/Pusat/Unit Kerja/Teknik Konversi Energi','aktif',2,'2021-12-23 08:58:32','2021-12-23 08:58:32'),(31,'Teknik Telekomunikasi - S2','storage/files/Pusat/Unit Kerja/Teknik Telekomunikasi - S2','aktif',1,'2021-12-24 15:25:24','2021-12-24 15:25:24'),(32,'Teknik Telekomunikasi - D4','storage/files/Pusat/Unit Kerja/Teknik Telekomunikasi - D4','aktif',1,'2021-12-24 15:25:34','2021-12-24 15:25:34'),(33,'Teknik Telekomunikasi - D3','storage/files/Pusat/Unit Kerja/Teknik Telekomunikasi - D3','aktif',1,'2021-12-24 15:25:44','2021-12-24 15:25:44'),(34,'Teknologi Rekayasa Instalasi Listrik','storage/files/Pusat/Unit Kerja/Teknologi Rekayasa Instalasi Listrik','aktif',1,'2021-12-24 15:25:59','2021-12-24 15:25:59'),(35,'Teknologi Rekayasa Komputer','storage/files/Pusat/Unit Kerja/Teknologi Rekayasa Komputer','aktif',1,'2021-12-24 15:26:07','2021-12-24 15:26:07'),(36,'Teknik Listrik','storage/files/Pusat/Unit Kerja/Teknik Listrik','aktif',1,'2021-12-24 15:26:17','2021-12-24 15:26:17'),(37,'Teknik Elektronika','storage/files/Pusat/Unit Kerja/Teknik Elektronika','aktif',1,'2021-12-24 15:26:26','2021-12-24 15:26:26'),(38,'Teknik Informatika','storage/files/Pusat/Unit Kerja/Teknik Informatika','aktif',1,'2021-12-24 15:26:33','2021-12-24 15:26:33'),(41,'Sistem Informasi','storage/files/Pusat/Unit Kerja/Sistem Informasi','aktif',1,'2022-01-15 05:18:52','2022-01-15 05:18:52');
/*!40000 ALTER TABLE `unitkerja` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `unitkerja_id` int(10) unsigned DEFAULT NULL,
  `status` enum('aktif','nonaktif') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  KEY `users_unitkerja_id_foreign` (`unitkerja_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_unitkerja_id_foreign` FOREIGN KEY (`unitkerja_id`) REFERENCES `unitkerja` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super admin','admin@admin.com','2021-07-08 08:00:29','$2y$10$7aTXy8ThU2hLPJFwBBuTbedvEA8WG650YSDxSz.Bi76j1j5HGjrge',1,NULL,'aktif','SuiFreBHNGACOKTdAkhGZaPb04objYHqFsAz1hX2XPbLKYzC3YTF54qsMaN7','2021-07-08 08:00:29','2021-07-08 15:00:29'),(2,'Auditor','auditor@admin.com',NULL,'$2y$10$rQUaXGzYK34wjDU2TRZg2OO0jD1DZyIJIM0U6JITACRmjcv/27nH.',2,17,'aktif',NULL,'2021-12-27 05:07:12','2021-12-27 12:07:12'),(3,'Auditee','auditee@admin.com',NULL,'$2y$10$1NI.sfPO18HWsWyVZy7pLuRtMSLn.wOLtFD/3R5BH4itaf67lU6K.',3,17,'aktif',NULL,'2021-12-27 05:07:12','2021-12-27 12:07:12'),(5,'Pimpinan','pimpinan@admin.com',NULL,'$2y$10$36Ux8nQUtY4pObpwMd4QteZZ56R02z2tkNDIhgzPvK6rQ33X2SEiG',4,NULL,'aktif',NULL,'2021-12-27 05:21:58','2021-12-27 12:21:58'),(6,'Pimpinan Akuntansi','pimpinanunit@admin.com',NULL,'$2y$10$WTv6mCSic49xwRvLfvjWJep/cZMRT9GLHnqqaLIau2mtYzEQG1dm6',4,17,'aktif',NULL,'2021-12-27 05:27:26','2021-12-27 12:27:26'),(7,'irfan ardian','irfanardian1@gmail.com',NULL,'$2y$10$X2.StPhRZSYVwjbrD.SYteSeD4dHwtOto4Pl3prnR0w9H6cnHmTfy',3,38,'aktif',NULL,'2022-01-19 06:49:35','2022-01-19 18:17:32'),(8,'trian','trian@gmail.com',NULL,'$2y$10$cdog96DI0jcOv0hLNn/b.Outfo2Ni80jMtL1fs7XBwwqmzuGmkax2',3,38,'aktif',NULL,'2022-01-19 11:14:02','2022-01-19 18:14:02');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_jadwalaudit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_jadwalaudit` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `jadwal_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_jadwalaudit_user_id_foreign` (`user_id`) USING BTREE,
  KEY `users_jadwalaudit_jadwal_id_foreign` (`jadwal_id`) USING BTREE,
  CONSTRAINT `users_jadwalaudit_ibfk_1` FOREIGN KEY (`jadwal_id`) REFERENCES `jadwal_audit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_jadwalaudit_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_jadwalaudit` WRITE;
/*!40000 ALTER TABLE `users_jadwalaudit` DISABLE KEYS */;
INSERT INTO `users_jadwalaudit` VALUES (1,2,1,'2021-12-27 05:37:30','2021-12-27 12:37:30'),(4,2,3,'2022-01-15 06:42:43','2022-01-15 13:42:43'),(5,2,4,'2022-01-15 06:42:43','2022-01-15 13:42:43'),(6,3,3,'2022-01-15 13:30:29','2022-01-15 20:30:29'),(8,3,5,'2022-01-16 02:57:39','2022-01-16 09:57:39'),(9,3,1,'2022-01-16 03:21:57','2022-01-16 10:21:57');
/*!40000 ALTER TABLE `users_jadwalaudit` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

